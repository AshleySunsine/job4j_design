# job4j_design
[![Build Status](https://travis-ci.org/AshleySunsine/job4j_design.svg?branch=master)](https://travis-ci.org/AshleySunsine/job4j_design)


[![codecov](https://codecov.io/gh/AshleySunsine/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/AshleySunsine/job4j_design)

